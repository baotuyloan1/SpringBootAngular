const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const app = express();
app.use(bodyParser.json());

// Setting for Hyperledger Fabric
const { Wallets, Gateway } = require("fabric-network");
const fs = require("fs");
const path = require("path");
const ccpPath = path.resolve(__dirname, ".", "connection-org1.json");
const fabproto6 = require("fabric-protos");
const { BlockDecoder } = require("fabric-common");
var sha = require("js-sha256");
var asn = require("asn1.js");
app.use(cors());

app.get("/blockchain/queryAllQuizzes", async function (req, res) {
  try {
    let ccp = JSON.parse(fs.readFileSync(ccpPath, "utf8"));
    // Create a new file system based wallet for managing identities.
    const walletPath = path.join(process.cwd(), "wallet");
    const wallet = await Wallets.newFileSystemWallet(walletPath);
    console.log(`Wallet path: ${walletPath}`);

    // Check to see if we've already enrolled the user.
    const identity = await wallet.get("appUser");
    if (!identity) {
      console.log(
        'An identity for the user "appUser" does not exist in the wallet'
      );
      console.log("Run the registerUser.js application before retrying");
      return;
    }

    // Create a new gateway for connecting to our peer node.
    const gateway = new Gateway();
    await gateway.connect(ccp, {
      wallet,
      identity: "appUser",
      discovery: { enabled: true, asLocalhost: true },
    });

    // Get the network (channel) our contract is deployed to.
    const network = await gateway.getNetwork("mychannel");

    // Get the contract from the network.
    const contract = network.getContract("fabcar");

    // Data block
    const contract1 = network.getContract("qscc");
    // const resultByte = await contract1.evaluateTransaction(
    //   "GetChainInfo",
    //   "mychannel"
    // );
    const resultByte = await contract1.evaluateTransaction(
      "GetChainInfo",
      "mychannel"
    );
    // console.log(resultByte.toString("utf-8"));
    // const resultJson = JSON.stringify(
    //   fabproto6.common.Block.decode(resultByte)
    // );
    const resultJson = JSON.stringify(
      fabproto6.common.BlockchainInfo.decode(resultByte)
    );
    //  JSON.stringify(fabproto6.common.BlockchainInfo.decode(result));

    console.log(resultJson);

    // Evaluate the specified transaction.
    // queryAllCars transaction - requires no arguments, ex: ('queryAllCars')
    const result = await contract.evaluateTransaction("queryStudents");
    // console.log(
    //   `Transaction has been evaluated, result is: ${result.toString("utf-8")}`
    // );
    res.status(200).end(result.toString("utf-8"));

    // Disconnect from the gateway.
    await gateway.disconnect();
  } catch (error) {
    console.error(`Failed to evaluate transaction: ${error}`);
    res.status(500).json({ error: error });
    process.exit(1);
  }
});
var calculateBlockHash = function (header) {
  let headerAsn = asn.define("headerAsn", function () {
    this.seq().obj(
      this.key("Number").int(),
      this.key("PreviousHash").octstr(),
      this.key("DataHash").octstr()
    );
  });

  let output = headerAsn.encode(
    {
      Number: parseInt(header.number),
      PreviousHash: Buffer.from(header.previous_hash, "hex"),
      DataHash: Buffer.from(header.data_hash, "hex"),
    },
    "der"
  );
  let hash = sha.sha256(output);
  return hash;
};
app.get("/api/blocks", async function (req, res) {
  try {
    let ccp = JSON.parse(fs.readFileSync(ccpPath, "utf8"));
    // Create a new file system based wallet for managing identities.
    const walletPath = path.join(process.cwd(), "wallet");
    const wallet = await Wallets.newFileSystemWallet(walletPath);
    console.log(`Wallet path: ${walletPath}`);

    // Check to see if we've already enrolled the user.
    const identity = await wallet.get("appUser");
    if (!identity) {
      console.log(
        'An identity for the user "appUser" does not exist in the wallet'
      );
      console.log("Run the registerUser.js application before retrying");
      return;
    }

    // Create a new gateway for connecting to our peer node.
    const gateway = new Gateway();
    await gateway.connect(ccp, {
      wallet,
      identity: "appUser",
      discovery: { enabled: true, asLocalhost: true },
    });

    // Get the network (channel) our contract is deployed to.
    const network = await gateway.getNetwork("mychannel");

    // Get the contract from the network.
    // Data block
    const contract = network.getContract("qscc");

    const resultByte = await contract.evaluateTransaction(
      "GetChainInfo",
      "mychannel"
    );

    const resultJson = JSON.stringify(
      fabproto6.common.BlockchainInfo.decode(resultByte)
    );

    const blocksInfo = JSON.parse(resultJson);
    const blocks = [];

    for (let i = blocksInfo.height - 1; i > -1; i--) {
      var block = await contract.evaluateTransaction(
        "GetBlockByNumber",
        "mychannel",
        i
      );

      const decodeBlockJSON = BlockDecoder.decode(block);

      // console.log(decodeBlockJSON.header.previous_hash);
      // blockValue.blockNumber = decodeBlockJSON.header.number.low;

      // var enc = new TextDecoder("utf-8");

      // blockValue.previousHash = decodeBlockJSON.header.previous_hash;
      // blockValue.previousHash.data = enc.decode( blockValue.previousHash.data);
      // console.log(calculateBlockHash(decodeBlockJSON.header));
      decodeBlockJSON.block_hash = calculateBlockHash(decodeBlockJSON.header);
      blocks.push(decodeBlockJSON);
    }

    // blocks = JSON.stringify(blocks);
    // res.status(200).end(blocks.toString("utf-8"));
    res.status(200).end(JSON.stringify(blocks));
    // Disconnect from the gateway.
    await gateway.disconnect();
  } catch (error) {
    console.error(`Failed to evaluate transaction: ${error}`);
    res.status(500).json({ error: error });
    process.exit(1);
  }
});

// get student by subject
app.get("/api/query/:subject", async function (req, res) {
  try {
    let ccp = JSON.parse(fs.readFileSync(ccpPath, "utf8"));
    // Create a new file system based wallet for managing identities.
    const walletPath = path.join(process.cwd(), "wallet");
    const wallet = await Wallets.newFileSystemWallet(walletPath);
    console.log(`Wallet path: ${walletPath}`);

    // Check to see if we've already enrolled the user.
    const identity = await wallet.get("appUser");
    if (!identity) {
      console.log(
        'An identity for the user "appUser" does not exist in the wallet'
      );
      console.log("Run the registerUser.js application before retrying");
      return;
    }

    // Create a new gateway for connecting to our peer node.
    const gateway = new Gateway();
    await gateway.connect(ccp, {
      wallet,
      identity: "appUser",
      discovery: { enabled: true, asLocalhost: true },
    });

    // Get the network (channel) our contract is deployed to.
    const network = await gateway.getNetwork("mychannel");

    // Get the contract from the network.
    const contract = network.getContract("fabcar");

    // Evaluate the specified transaction.
    // queryCar transaction - requires 1 argument, ex: ('queryCar', 'CAR4')
    // queryAllCars transaction - requires no arguments, ex: ('queryAllCars')
    const result = await contract.evaluateTransaction(
      "queryStudentsBySubject",
      req.params.subject
    );
    console.log(
      `Transaction has been evaluated, result is: ${result.toString("utf-8")}`
    );
    res.status(200).json({ response: result.toString() });

    // Disconnect from the gateway.
    await gateway.disconnect();
  } catch (error) {
    console.error(`Failed to evaluate transaction: ${error}`);
    res.status(500).json({ error: error });
    process.exit(1);
  }
});

app.get(
  "/blockchain/queryQuizStudent/:idStudentQuiz",
  async function (req, res) {
    try {
      // console.log(req.params.idStudentQuiz);
      let ccp = JSON.parse(fs.readFileSync(ccpPath, "utf8"));
      // Create a new file system based wallet for managing identities.
      const walletPath = path.join(process.cwd(), "wallet");
      const wallet = await Wallets.newFileSystemWallet(walletPath);
      console.log(`Wallet path: ${walletPath}`);

      // Check to see if we've already enrolled the user.
      const identity = await wallet.get("appUser");
      if (!identity) {
        console.log(
          'An identity for the user "appUser" does not exist in the wallet'
        );
        console.log("Run the registerUser.js application before retrying");
        return;
      }

      // Create a new gateway for connecting to our peer node.
      const gateway = new Gateway();
      await gateway.connect(ccp, {
        wallet,
        identity: "appUser",
        discovery: { enabled: true, asLocalhost: true },
      });

      // Get the network (channel) our contract is deployed to.
      const network = await gateway.getNetwork("mychannel");

      // Get the contract from the network.
      const contract = network.getContract("fabcar");

      // Evaluate the specified transaction.
      // queryCar transaction - requires 1 argument, ex: ('queryCar', 'CAR4')
      // queryAllCars transaction - requires no arguments, ex: ('queryAllCars')
      console.log(req.params.idStudentQuiz);
      const result = await contract.evaluateTransaction(
        "queryQuizStudent",
        req.params.idStudentQuiz
      );
      console.log(
        `Transaction has been evaluated, result is: ${result.toString("utf-8")}`
      );
      res.status(200).end(result.toString("utf-8"));

      // Disconnect from the gateway.
      await gateway.disconnect();
    } catch (error) {
      console.error(`Failed to evaluate transaction: ${error}`);
      res.status(500).json({ error: error });
      process.exit(1);
    }
  }
);

app.post("/api/a", async function (req, res) {
  try {
    console.log("Bao req" + JSON.stringify(req.body));
  } catch (error) {
    console.error(`Failed to submit transaction: ${error}`);
    process.exit(1);
  }
});
app.post("/blockchain/addStudentQuiz", async function (req, res) {
  try {
    // console.log("Bao vao");
    let ccp = JSON.parse(fs.readFileSync(ccpPath, "utf8"));
    // Create a new file system based wallet for managing identities.
    const walletPath = path.join(process.cwd(), "wallet");
    const wallet = await Wallets.newFileSystemWallet(walletPath);
    console.log(`Wallet path: ${walletPath}`);

    // Check to see if we've already enrolled the user.
    const identity = await wallet.get("appUser");
    if (!identity) {
      console.log(
        'An identity for the user "appUser" does not exist in the wallet'
      );
      console.log("Run the registerUser.js application before retrying");
      return;
    }

    // Create a new gateway for connecting to our peer node.
    const gateway = new Gateway();
    await gateway.connect(ccp, {
      wallet,
      identity: "appUser",
      discovery: { enabled: true, asLocalhost: true },
    });

    // Get the network (channel) our contract is deployed to.
    const network = await gateway.getNetwork("mychannel");

    // Get the contract from the network.
    const contract = network.getContract("fabcar");

    // Submit the specified transaction.
    // createCar transaction - requires 5 argument, ex: ('createCar', 'CAR12', 'Honda', 'Accord', 'Black', 'Tom')
    // changeCarOwner transaction - requires 2 args , ex: ('changeCarOwner', 'CAR10', 'Dave')

    var student = {
      quizName: req.body.quizName,
      studentName: req.body.studentName,
      mark: req.body.mark,
      numberWrong: req.body.numberWrong,
      numberBlank: req.body.numberBlank,
      numberQuestions: req.body.numberQuestions,
      numberTrue: req.body.numberTrue,
      quizDetail: req.body.quizDetail,
      createdTime: req.body.createdTime,
      submitQuizTime: req.body.submitQuizTime,
      createdBy: req.body.createdBy,
    };
    console.log(student);
    await contract.submitTransaction(
      "writeJsonData",
      req.body.id,
      JSON.stringify(student)
    );

    console.log("Transaction has been submitted");
    res.send(req.body);

    // Disconnect from the gateway.
    await gateway.disconnect();
  } catch (error) {
    console.error(`Failed to submit transaction: ${error}`);
    process.exit(1);
  }
});

// app.put("/api/changeowner/:car_index", async function (req, res) {
//   try {
//     let ccp = JSON.parse(fs.readFileSync(ccpPath, "utf8"));
//     // Create a new file system based wallet for managing identities.
//     const walletPath = path.join(process.cwd(), "wallet");
//     const wallet = await Wallets.newFileSystemWallet(walletPath);
//     console.log(`Wallet path: ${walletPath}`);

//     // Check to see if we've already enrolled the user.
//     const identity = await wallet.get("appUser");
//     if (!identity) {
//       console.log(
//         'An identity for the user "appUser" does not exist in the wallet'
//       );
//       console.log("Run the registerUser.js application before retrying");
//       return;
//     }

//     // Create a new gateway for connecting to our peer node.
//     const gateway = new Gateway();
//     await gateway.connect(ccp, {
//       wallet,
//       identity: "appUser",
//       discovery: { enabled: true, asLocalhost: false },
//     });

//     // Get the network (channel) our contract is deployed to.
//     const network = await gateway.getNetwork("mychannel");

//     // Get the contract from the network.
//     const contract = network.getContract("fabcar");

//     // Submit the specified transaction.
//     // createCar transaction - requires 5 argument, ex: ('createCar', 'CAR12', 'Honda', 'Accord', 'Black', 'Tom')
//     // changeCarOwner transaction - requires 2 args , ex: ('changeCarOwner', 'CAR10', 'Dave')
//     await contract.submitTransaction(
//       "changeCarOwner",
//       req.params.car_index,
//       req.body.owner
//     );
//     console.log("Transaction has been submitted");
//     res.sendStatus(200).send("Transaction has been submitted");

//     // Disconnect from the gateway.
//     await gateway.disconnect();
//   } catch (error) {
//     console.error(`Failed to submit transaction: ${error}`);
//     process.exit(1);
//   }
// });

app.listen(8081);
